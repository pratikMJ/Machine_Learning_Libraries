
import numpy as np
import random as rd
import matplotlib.pyplot as mtplb

input_list=[]
output_list=[]
final_list=[]
index_training=[]
k=10

def gradient_descent(vector_set,x_values):

    learning_rate=0.5
    hypothesis=0
    error=0
    len=x_values.__len__()

    for x in range(len):
        for y in range(vector_set.__len__()):
            x_i=1
            for z in range(y):
                x_i=x_i*x_values[x][0]
            hypothesis=hypothesis+vector_set[y]*x_i
        error=error+hypothesis-x_values[x][1]

    for x in range(vector_set.__len__()):
        vector_set[y]=vector_set[y]-learning_rate*(1/x_values.__len__())*error
    return vector_set

for i in range(k):
    input_list.append(np.random.random())

def generate_out(val):
    temp=np.sin(np.pi*2*val)
    temp=temp+np.random.normal(scale=0.3)
    return temp

for i in range(k):
    output_list.append(generate_out(input_list[i]))

for i in range(k):
    temp_list=[input_list[i],output_list[i]]
    final_list.append(temp_list)

index_training=rd.sample(range(0,9),8)

training_set=[]
test_set=[]

j=int(k*.8)

for i in range(j):
    training_set.append(final_list[index_training[i]])
print(training_set)

for i in range(k):
    if final_list[i] not in training_set:
        test_set.append(final_list[i])

#print(test_set)
#print(final_list)


n=9
k=10

for j in range(n):
    theta_vector = []
    for k in range(j + 1):
        theta_vector.append(0)
    for i in range(k):

        #print(theta_vector)
        theta_vector=gradient_descent(theta_vector,training_set)
        print(theta_vector)


mtplb.scatter(training_set[0],training_set[1])

mtplb.show()


