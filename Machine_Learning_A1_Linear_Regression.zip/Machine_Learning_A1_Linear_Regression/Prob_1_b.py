import random as rd
import numpy as np

file=open("output_1_b.txt",'w')
def generate_out(val):
    temp=np.sin(np.pi*2*val)
    temp=temp+np.random.normal(scale=0.3)
    return temp
count_example=10

input_list=[]
input_list=np.linspace(0,1,count_example)

output_list=[]
for i in range(count_example):
    output_list.append(generate_out(input_list[i]))

final_list=[]
for i in range(count_example):
    temp_list=[input_list[i],output_list[i]]
    final_list.append(temp_list)
print(final_list)
file.write("Generated List: "+str(final_list))

index_training=[]
training_example=int(count_example*.8)
index_training=rd.sample(range(0,count_example-1),training_example)

training_set=[]
for i in range(training_example):
    training_set.append(final_list[index_training[i]])
print(training_set)
file.write("\n")
file.write("Training Set: "+str(training_set))

test_set=[]
for i in range(count_example):
    if final_list[i] not in training_set:
        test_set.append(final_list[i])
print(test_set)
file.write("\n")
file.write("Test Set: "+str(test_set))
file.close()


