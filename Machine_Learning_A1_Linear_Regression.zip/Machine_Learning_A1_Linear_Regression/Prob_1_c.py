
import numpy as np
import random as rd

file=open("output_1_c.txt","w")

def generate_out(val):
    temp=np.sin(np.pi*2*val)
    temp=temp+np.random.normal(scale=0.3)
    return temp

def generate_hypothesis(value,vector):
    hypothesis=0
    for j in range(vector.__len__()):
        hypothesis=hypothesis+vector[j]*value**j
    return hypothesis

def calculate_error(vector,training_data):
    error_terms = []
    for i in range(vector.__len__()):
        error_val=0
        for j in range(training_data.__len__()):
            value=generate_hypothesis(training_data[j][0],vector)
            error_val=error_val+(value-training_data[j][1])*training_data[j][0]**i
        error_terms.append(error_val)
    return  error_terms

def gradient_descent(vector,training_data):
    learning_rate=0.05
    error_terms=calculate_error(vector,training_data)
    for j in range(vector.__len__()):
        vector[j]=vector[j]-learning_rate*(1/training_data.__len__())*error_terms[j]
    return vector

count_example=10

input_list=np.linspace(0,1,count_example)

output_list=[]
for i in range(count_example):
    output_list.append(generate_out(input_list[i]))

final_list=[]
for i in range(count_example):
    temp_list=[input_list[i],output_list[i]]
    final_list.append(temp_list)

index_training=[]
training_ratio=int(count_example*.8)
index_training=rd.sample(range(0,count_example-1),training_ratio)

training_set=[]
for i in range(training_ratio):
    training_set.append(final_list[index_training[i]])

test_set=[]
for i in range(count_example):
    if final_list[i] not in training_set:
        test_set.append(final_list[i])

n=9
iteration=1000
for i in range(n):
    theta_vector=[]
    for j in range(i+1):
        theta_vector.append(0)
    for j in range(iteration):
        theta_vector=gradient_descent(theta_vector,training_set)
    print(theta_vector)
    test_error=0
    sample_set=test_set
    for j in range(sample_set.__len__()):
        test_error=test_error+(generate_hypothesis(sample_set[j][0],theta_vector)-sample_set[j][1])**2

    print(test_error)
    file.write("\n")
    file.write(str(i)+"th Error: "+str(test_error))
file.close()



