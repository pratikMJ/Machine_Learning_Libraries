import numpy as np

file=open("output_1_a.txt","w")


def generate_out(val):
    temp=np.sin(np.pi*2*val)
    temp=temp+np.random.normal(scale=0.3)
    return temp
k=10

input_list=[]
input_list=np.linspace(0,1,k)

output_list=[]
for i in range(k):
    output_list.append(generate_out(input_list[i]))

final_list=[]
for i in range(k):
    temp_list=[input_list[i],output_list[i]]
    final_list.append(temp_list)

print(final_list)
file.write(str(final_list))
file.close()