import math

def isNumber(attribute_value):
    try:
        float(attribute_value)
        return True
    except ValueError:
        pass

####  Function to find GINI Index of a node  #####
def find_entropy(target_list):
    if len(target_list) > 1 and target_list[0].__len__()>1:
        list_class_yes = []
        list_class_no = []

        for i in range(target_list.__len__()):
            if target_list[i][target_list[0].__len__() - 1] == 'yes':
                list_class_yes.append(target_list[i])
            else:
                list_class_no.append(target_list[i])
        if list_class_yes.__len__()!=0 and list_class_no.__len__()!=0:
                entropy = - ((list_class_yes.__len__() / target_list.__len__()) * math.log(
                    (list_class_yes.__len__() / target_list.__len__()), 2)) - (
                                      (list_class_no.__len__() / target_list.__len__()) * math.log(
                                  (list_class_no.__len__() / target_list.__len__()), 2))
        else:
            entropy=0
        if entropy == 0:
            class_value = target_list[0][target_list[0].__len__() - 1]
        else:
            class_value = 'not yet found'
    else:
        entropy = 0
        if target_list.__len__()==1 and target_list[0].__len__()>1:
            class_value = target_list[0][target_list[0].__len__()-1]
        else:
            class_value='not yet found 1'
    return entropy, class_value

#### Function for finding gini for different splits based on different values of attribute
def find_entropy_attribute(target_data, split_index):
    current_attribute_value_list = []
    for j in range(target_data.__len__()):
        current_attribute_value_list.append(target_data[j][split_index])
    my_dict = dict.fromkeys(current_attribute_value_list)
    final_attrib_value_list = list(my_dict)

    children_dict={}
    for j in range(final_attrib_value_list.__len__()):
        child=[]
        for k in range(target_data.__len__()):
            if (target_data[k][split_index] == final_attrib_value_list[j]):
                child.append(target_data[k])
        children_dict[final_attrib_value_list[j]]=child
        entropy_list=[]
        for i in range(children_dict.__len__()):
            entropy_list.append(find_entropy(children_dict[final_attrib_value_list[i]]))
        entropy_index_children=0.0
        for i in range(entropy_list.__len__()):
            entropy_index_children = entropy_index_children+((children_dict[final_attrib_value_list[i]].__len__() / target_data.__len__()) * entropy_list[i][0])
        entropy_attribute=entropy_index_children
        best_value = ''

    return entropy_attribute, best_value

def find_entropy_split_attribute_wise(target_data):
    entropy_split_attribute_wise = []
    for i in range(target_data[0].__len__() - 1):
        entropy_for_attribute = find_entropy_attribute(target_data, i)
        entropy_split_attribute_wise.append(entropy_for_attribute[0])
    return entropy_split_attribute_wise

def grow_decision_tree(training_set,indent_value):
    target_set = training_set[1:training_set.__len__()]
    entropy_node = find_entropy(target_set)
    if entropy_node[0] == 0:
        value = entropy_node[1]
        print('\t\t\t\t\t' + 'class: ', value)
    else:
        entropy_set_attributes = find_entropy_split_attribute_wise(target_set)
        preferred_attribute_entropy = min(entropy_set_attributes)
        index_split_attribute = entropy_set_attributes.index(preferred_attribute_entropy)
        entropy_attribute_value = find_entropy_attribute(target_set, index_split_attribute)

        children_dict = {}
        attribute_value_list = []
        for j in range(target_set.__len__()):
            attribute_value_list.append(target_set[j][index_split_attribute])
        my_dict = dict.fromkeys(attribute_value_list)
        final_attrib_value_list = list(my_dict)
        for j in range(final_attrib_value_list.__len__()):
            childnode=[]
            t = list(training_set[0])
            childnode.append(t)
            for i in range(target_set.__len__()):
                if target_set[i][index_split_attribute] == final_attrib_value_list[j]:
                    childnode.append(target_set[i])
            children_dict[final_attrib_value_list[j]]=childnode
        indent_value += 1
        for i in range(children_dict.__len__()):
            for j in children_dict[final_attrib_value_list[i]]:
                del j[index_split_attribute]
        for i in range(children_dict.__len__()):
            print('\t' * indent_value, '|' + training_set[0][index_split_attribute] + '=' + final_attrib_value_list[i])
            grow_decision_tree(children_dict[final_attrib_value_list[i]],indent_value)


training_data = [['price', 'maintenance', 'capacity', 'airbag', 'profitable'],
                 ['low', 'low', '2', 'no', 'yes'],
                 ['low', 'med', '4', 'yes', 'no'],
                 ['low', 'high', '4', 'no', 'no'],
                 ['med', 'med', '4', 'no', 'no'],
                 ['med', 'med', '4', 'yes', 'yes'],
                 ['med', 'high', '2', 'yes', 'no'],
                 ['high', 'med', '4', 'yes', 'yes'],
                 ['high', 'high', '2', 'yes', 'no'],
                 ['high', 'high', '5', 'yes', 'yes']]


indent_value=0

#target_set = training_data[1:training_data.__len__()]
grow_decision_tree(training_data,indent_value)