#### Function to check if a string is a number  #####
def isNumber(attribute_value):
    try:
        float(attribute_value)
        return True
    except ValueError:
        pass


####  Function to find GINI Index of a node  #####
def find_gini(target_list):
    if target_list.__len__() > 1 and target_list[0].__len__()>1:
        list_class_yes = []
        list_class_no = []

        for i in range(target_list.__len__()):
            if target_list[i][target_list[0].__len__() - 1] == 'yes':
                list_class_yes.append(target_list[i])
            else:
                list_class_no.append(target_list[i])

        gini = 1 - ((list_class_yes.__len__() / (target_list.__len__())) ** 2) - (
                    (list_class_no.__len__() / (target_list.__len__())) ** 2)
        if gini == 0:
            class_value = target_list[0][target_list[0].__len__() - 1]
        else:
            class_value = 'not yet found'
    else:
        print("error")
        gini = 0
        if target_list.__len__()==1 and target_list[0].__len__()>1:
            class_value = target_list[0][target_list[0].__len__()-1]
        else:
            class_value='not yet found 1'
    return gini, class_value


#### Function for finding gini for different splits based on different values of attribute
def find_gini_attribute(target_data, split_index):
    current_attribute_value_list = []
    for j in range(target_data.__len__()):
        current_attribute_value_list.append(target_data[j][split_index])
    my_dict = dict.fromkeys(current_attribute_value_list)
    final_attrib_value_list = list(my_dict)
    attribute_value = final_attrib_value_list[0]
    gini_for_attribute = []
    if isNumber(attribute_value) == True:
        print("continuous attribute")
        gini_children_dict={}

        for j in range(final_attrib_value_list.__len__()):
            temp_list=[]
            for k in range(target_data.__len__()):
                if float(target_data[k][split_index]) == float(final_attrib_value_list[j]):
                   temp_list.append(target_data[k])
            gini_children_dict[str(final_attrib_value_list[j])]=temp_list

         for i in range(gini_children_dict.__len__()):
             temp_gini=find_gini(gini_children_dict[final_attrib_value_list[i]])
            child_branch_1_gini = find_gini(child_branch_1)
            child_branch_2_gini = find_gini(child_branch_2)
            gini_index_children = (child_branch_1.__len__() / (
                target_data.__len__()) * child_branch_1_gini[0]) + (child_branch_2.__len__() /
                                                                    target_data.__len__() * child_branch_2_gini[0])
            gini_for_attribute.append(gini_index_children)
        min_gini = min(gini_for_attribute)
        best_value = final_attrib_value_list[gini_for_attribute.index(min_gini)]
        # print("gini for attributes" + str(gini_for_attribute))

    else:
        print("categorical attribute")
        for j in range(final_attrib_value_list.__len__()):
            child_branch_1 = []
            child_branch_2 = []
            for k in range(target_data.__len__()):
                if (target_data[k][split_index] == final_attrib_value_list[j]):
                    child_branch_1.append(target_data[k])
                else:
                    child_branch_2.append(target_data[k])
            child_branch_1_gini = find_gini(child_branch_1)
            child_branch_2_gini = find_gini(child_branch_2)
            gini_index_children = (child_branch_1.__len__() / target_data.__len__() * child_branch_1_gini[0]) + (
                        child_branch_2.__len__() / target_data.__len__() * child_branch_2_gini[0])
            gini_for_attribute.append(gini_index_children)
        print("gini for attributes" + str(gini_for_attribute))
        min_gini = min(gini_for_attribute)
        best_value = final_attrib_value_list[gini_for_attribute.index(min_gini)]

    # print(best_value)
    return gini_for_attribute, best_value


#### Function for finding a list which will return the GINI index of splits for each attributes  ####
def find_gini_split_attribute_wise(target_data):
    gini_split_attribute_wise = []
    for i in range(target_data[0].__len__() - 1):
        gini_for_attribute = find_gini_attribute(target_data, i)
        #sum = 0
        #for k in range(gini_for_attribute[0].__len__()):
        #    sum = sum + gini_for_attribute[0][k]
        #avg = sum / gini_for_attribute[0].__len__()
        gini_split_attribute_wise.append(min(gini_for_attribute[0]))
    print("gini split index for all attributes:" + str(gini_split_attribute_wise))
    return gini_split_attribute_wise


def grow_decision_tree(target_set):
    gini_node = find_gini(target_set)
    print("gini root node: " + str(gini_node[0]))
    if gini_node[0] == 0:
        value = gini_node[1]
        print("class_value:" + value)
    else:
        gini_set_attributes = find_gini_split_attribute_wise(target_set)
        preferred_attribute_gini = min(gini_set_attributes)
        index_split_attribute = gini_set_attributes.index(preferred_attribute_gini)
        print("split attribute index: " + str(index_split_attribute))
        gini_attribute_value = find_gini_attribute(target_set, index_split_attribute)
        print("Training Data split: Attribute best Value " + gini_attribute_value[1])

        childnode_1 = []
        childnode_2 = []

        if isNumber(target_set[0][index_split_attribute]) == True:

            for i in range(target_set.__len__()):
                if target_set[i][index_split_attribute] == gini_attribute_value[1]:
                    childnode_1.append(target_set[i])
                else:
                    childnode_2.append(target_set[i])

        else:
            for i in range(target_set.__len__()):
                if target_set[i][index_split_attribute] == gini_attribute_value[1]:
                    childnode_1.append(target_set[i])
                else:
                    childnode_2.append(target_set[i])

        for i in childnode_1:
            del i[index_split_attribute]
        for i in childnode_2:
            del i[index_split_attribute]
        grow_decision_tree(childnode_1)
        grow_decision_tree(childnode_2)


training_data = [['price', 'maintenance', 'capacity', 'airbag', 'profitable'],
                 ['low', 'low', '2', 'no', 'yes'],
                 ['low', 'med', '4', 'yes', 'no'],
                 ['low', 'high', '4', 'no', 'no'],
                 ['med', 'med', '4', 'no', 'no'],
                 ['med', 'med', '4', 'yes', 'yes'],
                 ['med', 'high', '2', 'yes', 'no'],
                 ['high', 'med', '4', 'yes', 'yes'],
                 ['high', 'high', '2', 'yes', 'no'],
                 ['high', 'high', '5', 'yes', 'yes']]

target_set = training_data[1:training_data.__len__()]

grow_decision_tree(target_set)
