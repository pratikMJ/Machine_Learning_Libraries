import xlrd as xl

def isNumber(attribute_value):
    try:
        float(attribute_value)
        return True
    except ValueError:
        pass

####  Function to find GINI Index of a node  #####
def find_gini(target_list):
    if target_list.__len__() > 1 and target_list[0].__len__()>1:
        list_class_yes = []
        list_class_no = []

        for i in range(target_list.__len__()):
            if target_list[i][target_list[0].__len__() - 1] == 'yes':
                list_class_yes.append(target_list[i])
            else:
                list_class_no.append(target_list[i])

        gini = 1 - ((list_class_yes.__len__() / (target_list.__len__())) ** 2) - (
                    (list_class_no.__len__() / (target_list.__len__())) ** 2)
        if gini == 0:
            class_value = target_list[0][target_list[0].__len__() - 1]
        else:
            class_value = 'not yet found'
    else:
        gini = 0
        if target_list.__len__()==1 and target_list[0].__len__()>1:
            class_value = target_list[0][target_list[0].__len__()-1]
        else:
            class_value='not yet found 1'
    return gini, class_value

#### Function for finding gini for different splits based on different values of attribute
def find_gini_attribute(target_data, split_index):
    current_attribute_value_list = []
    for j in range(target_data.__len__()):
        current_attribute_value_list.append(target_data[j][split_index])
    my_dict = dict.fromkeys(current_attribute_value_list)
    final_attrib_value_list = list(my_dict)

    children_dict={}
    for j in range(final_attrib_value_list.__len__()):
        child=[]
        for k in range(target_data.__len__()):
            if (target_data[k][split_index] == final_attrib_value_list[j]):
                child.append(target_data[k])
            children_dict[final_attrib_value_list[j]]=child
        gini_list=[]
        for i in range(children_dict.__len__()):
            gini_list.append(find_gini(children_dict[final_attrib_value_list[i]]))
        gini_index_children=0.0
        for i in range(gini_list.__len__()):
            gini_index_children = gini_index_children+((children_dict[final_attrib_value_list[i]].__len__() / target_data.__len__()) * gini_list[i][0])
        gini_attribute=gini_index_children
        best_value = ''

    return gini_attribute, best_value

def find_gini_split_attribute_wise(target_data):
    gini_split_attribute_wise = []
    for i in range(target_data[0].__len__() - 1):
        gini_for_attribute = find_gini_attribute(target_data, i)
        gini_split_attribute_wise.append(gini_for_attribute[0])
    return gini_split_attribute_wise

def grow_decision_tree(training_set,indent_value):
    target_set=training_set[1:training_set.__len__()]
    gini_node = find_gini(target_set)
    #print("Gini Index:",gini_node[0])

    if gini_node[0] == 0:
        value = gini_node[1]
        print('\t\t\t\t\t'+'class: ',value)

    else:
        gini_set_attributes = find_gini_split_attribute_wise(target_set)

        preferred_attribute_gini = min(gini_set_attributes)
        index_split_attribute = gini_set_attributes.index(preferred_attribute_gini)
        gini_attribute_value = find_gini_attribute(target_set, index_split_attribute)
        #   print("gain: ",gini_node[0]-gini_attribute_value[0])

        children_dict = {}
        attribute_value_list = []
        for j in range(target_set.__len__()):
            attribute_value_list.append(target_set[j][index_split_attribute])
        my_dict = dict.fromkeys(attribute_value_list)
        final_attrib_value_list = list(my_dict)

        for j in range(final_attrib_value_list.__len__()):
            childnode=[]
            t=list(training_set[0])
            childnode.append(t)
            for i in range(target_set.__len__()):
                if target_set[i][index_split_attribute] == final_attrib_value_list[j]:
                    childnode.append(target_set[i])

            children_dict[final_attrib_value_list[j]]=childnode


        indent_value += 1
        for i in range(children_dict.__len__()):
            for j in children_dict[final_attrib_value_list[i]]:
                del j[index_split_attribute]

        for i in range(children_dict.__len__()):
            print('\t' * indent_value, '|' + training_set[0][index_split_attribute] + '=' + str(final_attrib_value_list[i]))
            grow_decision_tree(children_dict[final_attrib_value_list[i]],indent_value)

loc= "ML2_Datasets.xlsx"
workbook=xl.open_workbook(loc)
sheet1=workbook.sheet_by_name("SampleTraining")

list_train_label=[]
for i in range(sheet1.nrows):
    temp_list=[]
    for j in range(sheet1.ncols):
        temp_list.append(sheet1.cell_value(i,j))
    list_train_label.append(temp_list)

indent_value=0


grow_decision_tree(list_train_label,indent_value)