import xlrd as xl

loc= "ML2_Datasets.xlsx"
workbook=xl.open_workbook(loc)
sheet1=workbook.sheet_by_name("TrainingLabel")

list_train_label=[]
for i in range(1,sheet1.nrows):
    list_train_label.append([int(sheet1.cell_value(i,0)),int(sheet1.cell_value(i,1))])

print(list_train_label)

sheet2=workbook.sheet_by_name("TrainingData")
list_train_data=[]
for i in range(1,sheet2.nrows):
    list_train_data.append([int(sheet2.cell_value(i,0)),int(sheet2.cell_value(i,1))])
print(list_train_data)

sheet3=workbook.sheet_by_name("Word")

val=sheet3.nrows
training_list=[[0]*val for i in range(len(list_train_label)+1)]
for x,y in list_train_data:
    training_list[x][y]=1
print(training_list)


