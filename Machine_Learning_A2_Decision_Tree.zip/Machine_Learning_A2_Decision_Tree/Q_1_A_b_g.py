def isNumber(attribute_value):
    try:
        float(attribute_value)
        return True
    except ValueError:
        pass

####  Function to find GINI Index of a node  #####
def find_gini(target_list):
    if target_list.__len__() > 1 and target_list[0].__len__()>1:
        list_class_yes = []
        list_class_no = []

        for i in range(target_list.__len__()):
            if target_list[i][target_list[0].__len__() - 1] == 'yes':
                list_class_yes.append(target_list[i])
            else:
                list_class_no.append(target_list[i])

        gini = 1 - ((list_class_yes.__len__() / (target_list.__len__())) ** 2) - (
                    (list_class_no.__len__() / (target_list.__len__())) ** 2)
        if gini == 0:
            class_value = target_list[0][target_list[0].__len__() - 1]
        else:
            class_value = 'not yet found'
    else:
        gini = 0
        if target_list.__len__()==1 and target_list[0].__len__()>1:
            class_value = target_list[0][target_list[0].__len__()-1]
        else:
            class_value='not yet found 1'
    return gini, class_value

#### Function for finding gini for different splits based on different values of attribute
def find_gini_attribute(target_data, split_index):
    current_attribute_value_list = []
    for j in range(target_data.__len__()):
        current_attribute_value_list.append(target_data[j][split_index])
    my_dict = dict.fromkeys(current_attribute_value_list)
    final_attrib_value_list = list(my_dict)
    attribute_value = final_attrib_value_list[0]
    gini_for_attribute = []
    if isNumber(attribute_value) == True:
        for j in range(final_attrib_value_list.__len__()):
            child_branch_1 = []
            child_branch_2 = []
            for k in range(target_data.__len__()):
                if float(target_data[k][split_index]) < float(final_attrib_value_list[j]):
                    child_branch_1.append(target_data[k])
                else:
                    child_branch_2.append(target_data[k])
            child_branch_1_gini = find_gini(child_branch_1)
            child_branch_2_gini = find_gini(child_branch_2)
            gini_index_children = (child_branch_1.__len__() / (
                target_data.__len__()) * child_branch_1_gini[0]) + (child_branch_2.__len__() /
                                                                    target_data.__len__() * child_branch_2_gini[0])
            gini_for_attribute.append(gini_index_children)
        gini_attribute = min(gini_for_attribute)
        best_value = final_attrib_value_list[gini_for_attribute.index(gini_attribute)]

    else:
        children_dict={}
        for j in range(final_attrib_value_list.__len__()):
            child=[]
            for k in range(target_data.__len__()):
                if (target_data[k][split_index] == final_attrib_value_list[j]):
                    child.append(target_data[k])
            children_dict[final_attrib_value_list[j]]=child
        gini_list=[]
        for i in range(children_dict.__len__()):
            gini_list.append(find_gini(children_dict[final_attrib_value_list[i]]))
        gini_index_children=0.0
        for i in range(gini_list.__len__()):
            gini_index_children = gini_index_children+((children_dict[final_attrib_value_list[i]].__len__() / target_data.__len__()) * gini_list[i][0])
        gini_attribute=gini_index_children
        best_value = ''

    return gini_attribute, best_value

def find_gini_split_attribute_wise(target_data):
    gini_split_attribute_wise = []
    for i in range(target_data[0].__len__() - 1):
        gini_for_attribute = find_gini_attribute(target_data, i)
        gini_split_attribute_wise.append(gini_for_attribute[0])
    return gini_split_attribute_wise

def grow_decision_tree(training_set):
    target_set=training_set[1:training_set.__len__()]
    print(training_set)
    print(target_set)
    gini_node = find_gini(target_set)
    if gini_node[0] == 0:
        value = gini_node[1]
        print("class: " + value)
    else:
        gini_set_attributes = find_gini_split_attribute_wise(target_set)
        print(gini_set_attributes)
        preferred_attribute_gini = min(gini_set_attributes)
        index_split_attribute = gini_set_attributes.index(preferred_attribute_gini)
        gini_attribute_value = find_gini_attribute(target_set, index_split_attribute)
        print(gini_attribute_value)

        if isNumber(target_set[0][index_split_attribute]) == True:
            childnode_1=[]
            childnode_1.append(training_set[0])
            childnode_2=[]
            childnode_2.append(training_set[0])
            for i in range(target_set.__len__()):
                if target_set[i][index_split_attribute] < gini_attribute_value[1]:
                    childnode_1.append(target_set[i])
                else:
                    childnode_2.append(target_set[i])
            for i in childnode_1:
                del i[index_split_attribute]
            for i in childnode_2:
                del i[index_split_attribute]
            grow_decision_tree(childnode_1)
            grow_decision_tree(childnode_2)

        else:
            children_dict = {}
            attribute_value_list = []
            for j in range(target_set.__len__()):
                attribute_value_list.append(target_set[j][index_split_attribute])

            my_dict = dict.fromkeys(attribute_value_list)
            final_attrib_value_list = list(my_dict)
            print(final_attrib_value_list)
            for j in range(final_attrib_value_list.__len__()):
                childnode=[]
                t=list(training_set[0])
                childnode.append(t)
                for i in range(target_set.__len__()):
                    if target_set[i][index_split_attribute] == final_attrib_value_list[j]:
                        childnode.append(target_set[i])
                children_dict[final_attrib_value_list[j]]=childnode

            print(children_dict)
            print(index_split_attribute )
            for i in range(children_dict.__len__()):
                for j in children_dict[final_attrib_value_list[i]]:
                    print("ABCD" ,i,j)
                    del j[index_split_attribute]
            print(children_dict)
            for i in range(children_dict.__len__()):
                 grow_decision_tree(children_dict[final_attrib_value_list[i]])


training_data = [['price', 'maintenance', 'capacity', 'airbag', 'profitable'],
                 ['low', 'low', '2', 'no', 'yes'],
                 ['low', 'med', '4', 'yes', 'no'],
                 ['low', 'high', '4', 'no', 'no'],
                 ['med', 'med', '4', 'no', 'no'],
                 ['med', 'med', '4', 'yes', 'yes'],
                 ['med', 'high', '2', 'yes', 'no'],
                 ['high', 'med', '4', 'yes', 'yes'],
                 ['high', 'high', '2', 'yes', 'no'],
                 ['high', 'high', '5', 'yes', 'yes']]

#target_set = training_data[1:training_data.__len__()]
grow_decision_tree(training_data)