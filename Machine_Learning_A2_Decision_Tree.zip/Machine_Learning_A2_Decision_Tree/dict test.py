my_dict={}
my_dict["india"]=[['delhi',7],['kolkata',8],['kharagpur',9]]
my_dict["pakistan"]=[['islamabad',11],['lahore',32],['karachi',99],['multan',177]]
#my_dict["india"]='kolkata'
list=["india","pakistan"]
#print(my_dict.get())
print(my_dict.__len__())
for i in range(my_dict.__len__()):
    print(my_dict.get(list[i]).__len__())
#print(my_dict)