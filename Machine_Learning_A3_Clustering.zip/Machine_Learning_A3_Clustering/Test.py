
var1=input("enter 1st number: ")
var2=input("enter 2nd number: ")

print(var1,var2)

