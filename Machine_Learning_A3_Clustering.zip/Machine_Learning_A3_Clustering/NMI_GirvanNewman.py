import networkx as nw
import csv
import math

def intersection(list1,list2):
    temp=[value for value in list1 if value in list2]
    return temp

def union(list1,list2):
    temp = [value for value in list1 if value not in list2]
    for i in range(len(list2)):
        temp.append(list2[i])
    return temp

def find_jaccard(list1,list2):
    set_union=union(list1,list2)
    set_intersection=intersection(list1,list2)
    value=len(set_intersection)/len(set_union)
    return value

training_file_name='AAAI.csv'
training_data=[]

with open(training_file_name,'r',encoding="utf8") as training_csv:
    csvreader=csv.reader(training_csv)
    for row in csvreader:
        training_data.append(row)

training_list=[]
for row in range(1,len(training_data)):
    tempList1=[]
    tempList1.append(row)
    tempList2 = training_data[row][2].split('\n')
    tempList3=[tempList1,tempList2]
    training_list.append(tempList3)

training_list_1=[]
for row in range(1,len(training_data)):

    tempList10 = training_data[row][2].split('\n')
    tempList11 = training_data[row][3]
    tempList12 = [row,tempList10,tempList11]
    training_list_1.append(tempList12)

gold_standard_list=[]
high_level_list=[]
for i in range(len(training_list_1)):
    high_level_list.append(training_list_1[i][2])
high_level_list_distinct=list(dict.fromkeys(high_level_list))
for i in range(len(high_level_list_distinct)):
    col_1=[]
    col_2=[]
    for j in range(len(training_list_1)):
        if high_level_list_distinct[i]==training_list_1[j][2]:
            col_1.append(training_list_1[j][0])
    gold_standard_list.append(col_1)

new_graph=nw.Graph()
for row in range(1,len(training_list)+1):
    new_graph.add_node(row)

for row in range(1,len(training_list)+1):
    for col in range(1,len(training_list)+1):
        if row!=col:
            jaccard=find_jaccard(training_list[row-1][1],training_list[col-1][1])
            if jaccard>=0.2:
                new_graph.add_edges_from([(row,col)])
cluster=nw.number_connected_components(new_graph)
while cluster!=9:
    betweenness=nw.edge_betweenness_centrality(new_graph)
    maximum=max(betweenness,key=betweenness.get)
    new_list=list(maximum)
    new_graph.remove_edge(new_list[0],new_list[1])
    cluster=nw.number_connected_components(new_graph)

nw.draw_networkx(new_graph)
comps=list(nw.connected_components(new_graph))
final_list=[]
for i in comps:
    tempList=list(i)
    final_list.append(tempList)

numerator=0
hsigma=0
hclass=0
for i in range(len(final_list)):
    for j in range(len(gold_standard_list)):
        list_term1=intersection(final_list[i],gold_standard_list[j])
        training_samples=len(training_data)-1
        len_cluster=len(final_list[i])
        len_class=len(gold_standard_list[j])
        numerator_1=len(list_term1)/training_samples
        numerator_2_1=(training_samples*len(list_term1))/(len_cluster*len_class)
        if(numerator_2_1!=0):
            numerator_2=math.log(numerator_2_1)
        else:
            numerator_2=0
        numerator_temp=numerator_1*numerator_2
        numerator=numerator+numerator_temp

for i in range(len(training_list)):
    len_cluster = len(training_list[i][0])
    training_samples = len(training_data)-1
    denominator1_1=len_cluster/training_samples
    denominator1_2=math.log(denominator1_1)
    denominator1=denominator1_1*denominator1_2
    hsigma=hsigma-denominator1

for i in range(len(gold_standard_list)):
    len_class = len(gold_standard_list[i])
    training_samples = len(training_data)-1
    denominator1_1=len_class/training_samples
    denominator1_2=math.log(denominator1_1)
    denominator1=denominator1_1*denominator1_2
    hclass=hclass-denominator1

NMI=numerator/((hsigma+hclass)/2)
print("NMI Girvan-Newman: ",NMI)