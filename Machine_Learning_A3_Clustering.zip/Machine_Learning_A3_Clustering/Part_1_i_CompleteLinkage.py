import csv

training_file_name='AAAI.csv'
training_data=[]

with open(training_file_name,'r',encoding="utf8") as training_csv:
    csvreader=csv.reader(training_csv)
    for row in csvreader:
        training_data.append(row)
    #print(training_data)

training_list=[]
for row in range(1,len(training_data)):
    tempList1=[]
    tempList1.append(row)
    tempList2 = training_data[row][2].split('\n')
    tempList3=[tempList1,tempList2]
    training_list.append(tempList3)

def intersection(list1,list2):
    temp=[value for value in list1 if value in list2]
    return temp

def union(list1,list2):
    temp = [value for value in list1 if value not in list2]
    for i in range(len(list2)):
        temp.append(list2[i])
    return temp

def find_jaccard(list1,list2):
    set_union=union(list1,list2)
    set_intersection=intersection(list1,list2)
    value=len(set_intersection)/len(set_union)
    return value

def mergeCluster(rowC,colC):
    tempList4=training_list[rowC][1]
    tempList5=training_list[colC][1]
    tempList6=union(tempList4,tempList5)
    tempList7=training_list[rowC][0]+training_list[colC][0]
    tempList8=[tempList7,tempList6]
    tempValue1=training_list[rowC]
    tempValue2=training_list[colC]
    training_list.remove(tempValue1)
    training_list.remove(tempValue2)
    training_list.append(tempList8)

while len(training_list)!=9:

    val = len(training_list)
    similarity_matrix = [[0] * val for i in range(len(training_list))]
    for row in range(len(training_list)):
        for col in range(len(training_list)):
            similarity_matrix[row][col]=find_jaccard(training_list[row][1],training_list[col][1])

    max_jaccard=0.0
    for row in range(len(similarity_matrix)):
        for col in range(len(similarity_matrix)):
            if row!=col:
                if similarity_matrix[row][col]>max_jaccard:
                    max_jaccard=similarity_matrix[row][col]
    list_new=[]
    for row in range(len(similarity_matrix)):
        for col in range(len(similarity_matrix)):
            if row!=col:
                if similarity_matrix[row][col]==max_jaccard:
                    temp=[row,col]
                    list_new.append(temp)
    rowC=list_new[0][0]
    colC=list_new[0][1]

    mergeCluster(rowC,colC)
print("Printing list of clusters:...... \n")
for i in range(len(training_list)):
     print("cluster ",i+1,training_list[i][0])
     print("length of the cluster:",len(training_list[i][0]))
     print("\n")





