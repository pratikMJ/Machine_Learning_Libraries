import csv
import math

def intersection(list1,list2):
    temp=[value for value in list1 if value in list2]
    return temp

def union(list1,list2):
    temp = [value for value in list1 if value not in list2]
    for i in range(len(list2)):
        temp.append(list2[i])
    return temp

def find_jaccard(list1,list2):
    set_union=union(list1,list2)
    set_intersection=intersection(list1,list2)
    value=len(set_intersection)/len(set_union)
    return value

def mergeCluster(rowC,colC):
    tempList4=training_list[rowC][1]
    tempList5=training_list[colC][1]
    tempList6=union(tempList4,tempList5)
    tempList7=training_list[rowC][0]+training_list[colC][0]
    tempList8=[tempList7,tempList6]
    tempValue1 = training_list[rowC]
    tempValue2 = training_list[colC]
    training_list.remove(tempValue1)
    training_list.remove(tempValue2)
    training_list.append(tempList8)


training_file_name='AAAI.csv'
training_data=[]

with open(training_file_name,'r',encoding="utf8") as training_csv:
    csvreader=csv.reader(training_csv)
    for row in csvreader:
        training_data.append(row)

training_list=[]
for row in range(1,len(training_data)):
    tempList1=[]
    tempList1.append(row)
    tempList2 = training_data[row][2].split('\n')
    tempList3=[tempList1,tempList2]
    training_list.append(tempList3)

training_list_1=[]
for row in range(1,len(training_data)):

    tempList10 = training_data[row][2].split('\n')
    tempList11 = training_data[row][3]
    tempList12 = [row,tempList10,tempList11]
    training_list_1.append(tempList12)

gold_standard_list=[]
high_level_list=[]
for i in range(len(training_list_1)):
    high_level_list.append(training_list_1[i][2])
high_level_list_distinct=list(dict.fromkeys(high_level_list))
for i in range(len(high_level_list_distinct)):
    col_1=[]
    col_2=[]
    for j in range(len(training_list_1)):
        if high_level_list_distinct[i]==training_list_1[j][2]:
            col_1.append(training_list_1[j][0])
    gold_standard_list.append(col_1)

while len(training_list)!=9:

    val = len(training_list)
    similarity_matrix = [[0] * val for i in range(len(training_list))]
    for row in range(len(training_list)):
        for col in range(len(training_list)):
            similarity_matrix[row][col]=find_jaccard(training_list[row][1],training_list[col][1])

    max_jaccard=1.0
    for row in range(len(similarity_matrix)):
        for col in range(len(similarity_matrix)):
            if row!=col:
                if similarity_matrix[row][col]<max_jaccard:
                    max_jaccard=similarity_matrix[row][col]
    list_new=[]
    for row in range(len(similarity_matrix)):
        for col in range(len(similarity_matrix)):
            if row!=col:
                if similarity_matrix[row][col]==max_jaccard:
                    temp=[row,col]
                    list_new.append(temp)
    rowC=list_new[0][0]
    colC=list_new[0][1]

    mergeCluster(rowC,colC)

numerator=0
hsigma=0
hclass=0
for i in range(len(training_list)):
    for j in range(len(gold_standard_list)):
        list_term1=intersection(training_list[i][0],gold_standard_list[j])
        training_samples=len(training_data)-1
        len_cluster=len(training_list[i][0])
        len_class=len(gold_standard_list[j])
        numerator_1=len(list_term1)/training_samples
        numerator_2_1=(training_samples*len(list_term1))/(len_cluster*len_class)
        if(numerator_2_1!=0):
            numerator_2=math.log(numerator_2_1)
        else:
            numerator_2=0
        numerator_temp=numerator_1*numerator_2
        numerator=numerator+numerator_temp

for i in range(len(training_list)):
    len_cluster = len(training_list[i][0])
    training_samples = len(training_data)-1
    denominator1_1=len_cluster/training_samples
    denominator1_2=math.log(denominator1_1)
    denominator1=denominator1_1*denominator1_2
    hsigma=hsigma-denominator1

for i in range(len(gold_standard_list)):
    len_class = len(gold_standard_list[i])
    training_samples = len(training_data)-1
    denominator1_1=len_class/training_samples
    denominator1_2=math.log(denominator1_1)
    denominator1=denominator1_1*denominator1_2
    hclass=hclass-denominator1

NMI=numerator/((hsigma+hclass)/2)
print("NMI Simple Linkage: ",NMI)

