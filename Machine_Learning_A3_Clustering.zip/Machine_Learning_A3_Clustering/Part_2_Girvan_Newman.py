import networkx as nw
import csv
import matplotlib.pyplot as plot


training_file_name='AAAI.csv'
training_data=[]

with open(training_file_name,'r',encoding="utf8") as training_csv:
    csvreader=csv.reader(training_csv)
    for row in csvreader:
        training_data.append(row)

training_list=[]
for row in range(1,len(training_data)):
    tempList1=[]
    tempList1.append(row)
    tempList2 = training_data[row][2].split('\n')
    tempList3=[tempList1,tempList2]
    training_list.append(tempList3)

def intersection(list1,list2):
    temp=[value for value in list1 if value in list2]
    return temp

def union(list1,list2):
    temp = [value for value in list1 if value not in list2]
    for i in range(len(list2)):
        temp.append(list2[i])
    return temp

def find_jaccard(list1,list2):
    set_union=union(list1,list2)
    set_intersection=intersection(list1,list2)
    value=len(set_intersection)/len(set_union)
    return value

new_graph=nw.Graph()
for row in range(1,len(training_list)+1):
    new_graph.add_node(row)

for row in range(1,len(training_list)+1):
    for col in range(1,len(training_list)+1):
        if row!=col:
            jaccard=find_jaccard(training_list[row-1][1],training_list[col-1][1])
            if jaccard>=0.2:
                new_graph.add_edges_from([(row,col)])
cluster=nw.number_connected_components(new_graph)
while cluster!=9:
    betweenness=nw.edge_betweenness_centrality(new_graph)
    maximum=max(betweenness,key=betweenness.get)
    new_list=list(maximum)
    new_graph.remove_edge(new_list[0],new_list[1])
    cluster=nw.number_connected_components(new_graph)

nw.draw_networkx(new_graph)
comps=list(nw.connected_components(new_graph))
final_list=[]
print("Printing the clusters:........\n")
count=1
for i in comps:
    tempList=list(i)
    final_list.append(tempList)
    print("cluster: ",count,i)
    print("length of the cluster: ",len(i))
    print("\n")
    count+=1
plot.show()
