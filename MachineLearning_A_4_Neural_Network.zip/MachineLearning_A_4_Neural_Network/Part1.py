import numpy as np
import pandas as pd
import random
from collections import Counter


import pprint
import time
import sys

data_list = pd.read_csv('Assignment_4_data.txt',delimiter="\t",header=None,names=["classification","message"])
print(data_list)
rows=len(data_list)
print("total number of rows",rows)

data_list['class_val'] = data_list.classification.map({'ham':0, 'spam':1})
print(data_list)