import numpy as np
import pandas as pd
import random
from collections import Counter


import pprint
import time
import sys
data = pd.read_csv('Assignment_4_data.txt',delimiter="\t",header=None,names=["label","text"])
print(data)
tr=len(data)
print("total number of rows",tr)
data = data.rename(columns={"v1":"label", "v2":"text"})
data['label_tag'] = data.label.map({'ham':0, 'spam':1})
print(data)
data.label.value_counts()
#tlimit=tr*0.80
#print(tlimit)
training_data = data[0:4457]
training_data_length = len(training_data.label)

test_data = data[4457:]
test_data_length = len(test_data.label)

print(training_data.shape)
print(training_data.label.shape)
print(test_data.shape)
print(test_data.label.shape)



