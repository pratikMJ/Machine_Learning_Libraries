import re
import string
from nltk.stem import PorterStemmer
import random as rd

stopwords=["i", "me", "my", "myself", "we", "our", "ours",
        "ourselves", "you", "your", "yours", "yourself", "yourselves",
        "he", "him", "his", "himself", "she", "her", "hers", "herself",
        "it", "its", "itself", "they", "them", "their", "theirs", "themselves",
        "what", "which", "who", "whom", "this", "that", "these", "those", "am",
        "is", "are", "was", "were", "be", "been", "being", "have", "has", "had",
        "having", "do", "does", "did", "doing", "a", "an", "the", "and", "but", "if",
        "or", "because", "as", "until", "while", "of", "at", "by", "for", "with", "about",
        "against", "between", "into", "through", "during", "before", "after", "above",
        "below", "to", "from", "up", "down", "in", "out", "on", "off", "over", "under",
        "again", "further", "then", "once", "here", "there", "when", "where", "why", "how",
        "all", "any", "both", "each", "few", "more", "most", "other", "some", "such", "no",
        "nor", "not", "only", "own", "same", "so", "than", "too", "very", "s", "t", "can",
        "will", "just", "don", "should", "now"]

def relu(value):
        output=max(0,value)
        return output

with open("Assignment_4_data.txt", "r") as ins:
    array = []
    for line in ins:
        array.append(line)
final=[]
for i in range(len(array)):
        array[i] = array[i].strip()
        list = array[i].split("\t",1)
        class_val=list[0]
        tokens=list[1]
        list[1]=list[1].lower()
        table = str.maketrans({key: None for key in string.punctuation})
        list[1] = list[1].translate(table)
        list[1]=re.sub(' +',' ',list[1])
        list[1]=list[1].split()
        for j in range(len(list[1])):
                if list[1][j] not in stopwords:
                        ps = PorterStemmer()
                        list[1][j]=ps.stem(list[1][j])
        list[1]= [x for x in list[1] if x not in stopwords]
        final.append(list)
count_example = len(final)
index_training = []
training_ratio = int(count_example * .8)
index_training = rd.sample(range(0, count_example - 1), training_ratio)

training_set = []
for i in range(training_ratio):
    training_set.append(final[index_training[i]])
print(training_set)

test_set = []
for i in range(count_example):
    if final[i] not in training_set:
        test_set.append(final[i])
print(test_set)

distinct_token_set=[]
for i in range (len(training_set)):
        for j in range(len(training_set[i][1])):
                if training_set[i][1][j] not in distinct_token_set:
                        distinct_token_set.append(training_set[i][1][j])
inputs=len(distinct_token_set)
classifier_output=[]
for i in range(len(training_set)):
        message_vector=[]
        for j in range(inputs):
                if distinct_token_set[j] in training_set[i][1]:
                        message_vector.append(1)
                else:
                        message_vector.append(0)
        layer_output=[]
        bias_node = 1
        bias_weight = 0.5
        bias = bias_node * bias_weight
        for x in range (100):
                weight_vector=[]
                for w in range(len(message_vector)):
                        weight_vector.append(rd.randrange(-1,1))
                sum=bias
                for w in range (len(message_vector)):
                        sum=sum+weight_vector[w]*message_vector[w]

                sum=relu(sum)
                layer_output.append(sum)
        weight_vector1 = []
        for x in range (len(layer_output)):
                weight_vector1.append(rd.randrange(-1,1))
        sum=bias
        for x in range (len(layer_output)):
                sum=sum+weight_vector1[x]*layer_output[x]
        sum=relu(sum)
        threshold=0.5
        if sum>=threshold:
                classifier_output.append("SPAM")
        else:
                classifier_output.append("HAM")
        print(i,sum, training_set[i][0],classifier_output[i])



